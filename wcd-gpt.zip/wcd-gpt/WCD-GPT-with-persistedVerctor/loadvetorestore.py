import os
import openai
from flask import Flask, request
from dotenv import load_dotenv
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.document_loaders import DirectoryLoader
from langchain.document_loaders import TextLoader
from langchain.text_splitter import TokenTextSplitter
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.llms import AzureOpenAI
from langchain.chains import RetrievalQA
from langchain.chains import LLMChain
from langchain.vectorstores import Chroma
from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import PromptTemplate
from langchain.vectorstores import FAISS

# Configure Azure OpenAI Service API
openai.api_type = "azure"
openai.api_version = "2023-03-15-preview"


embedding_1 = OpenAIEmbeddings(model="text-embedding-ada-002",
                    model_kwargs={"engine": 'dep-embed-ada'},
                    openai_api_key='dcf666b8b88d42dfa6595bef3698b4f6',
                    openai_api_base='https://api.chatgpt.tomtom-global.com/',
                    chunk_size=10)


# First, we load up our documents from the `data` directory:

loader = CSVLoader(file_path="2024_extended_data.csv")
data = loader.load()

persistent_directory = '/tmp/wcd-gpt/WCD-GPT-with-persistedVerctor/VectoreStore/'
db = Chroma.from_documents(data, embedding_1, persist_directory=persistent_directory)
db.persist()

