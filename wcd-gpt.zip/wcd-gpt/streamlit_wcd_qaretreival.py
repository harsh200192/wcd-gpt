import streamlit as st
from streamlit_chat import message
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain, RetrievalQA
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.vectorstores import FAISS
import tempfile
import os
import openai
from dotenv import load_dotenv
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma, FAISS
from langchain.document_loaders import DirectoryLoader
from langchain.document_loaders import TextLoader
from langchain.text_splitter import TokenTextSplitter
from langchain.document_loaders.csv_loader import CSVLoader
#from langchain.chains import ConversationalRetrievalChain
from langchain import PromptTemplate
from langchain.memory import ConversationBufferMemory

# Configure Azure OpenAI Service API
openai.api_type = "azure"
openai.api_version = "2023-03-15-preview"

#Init LLM and embeddings model
llm = AzureChatOpenAI(deployment_name="dep-gpt-4-32k",
                      temperature=0.7,
                      max_tokens=9000,
                      openai_api_version="2023-07-01-preview",
                      openai_api_key='6247e053edd340b2991cc7691c375a4b',
                      openai_api_base='https://api.chatgpt.tomtom-global.com/')

embeddings = OpenAIEmbeddings(model="text-embedding-ada-002",
                    model_kwargs={"engine": 'dep-embed-ada'},
                    openai_api_key='6247e053edd340b2991cc7691c375a4b',
                    openai_api_base='https://api.chatgpt.tomtom-global.com/',
                    embedding_ctx_length = 1000000,
                    show_progress_bar = True, 
                    skip_empty = False,
                    chunk_size=10)

print(embeddings)
loader = CSVLoader(file_path="dv1.csv") 
data = loader.load()
text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(data)
db = Chroma.from_documents(documents=docs, embedding=embeddings)

print(db)

loader = CSVLoader(file_path="dv2.csv") 
data = loader.load()
text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(data)
db = Chroma.from_documents(documents=docs, embedding=embeddings)

loader = CSVLoader(file_path="dv3.csv") 
data = loader.load()
text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(data)
db = Chroma.from_documents(documents=docs, embedding=embeddings)

loader = CSVLoader(file_path="dv4.csv") 
data = loader.load()
text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(data)
db = Chroma.from_documents(documents=docs, embedding=embeddings)

loader = CSVLoader(file_path="dv5.csv") 
data = loader.load()
text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(data)
db = Chroma.from_documents(documents=docs, embedding=embeddings)

loader = CSVLoader(file_path="dv6.csv") 
data = loader.load()
text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(data)
db = Chroma.from_documents(documents=docs, embedding=embeddings)

st.title("WCD-GPT")

choices = {'Short Answer' : 'stuff', 'Answer with Context' : 'refine'}


options = st.sidebar.selectbox("Answering options:-",
                       ('Short Answer', 'Answer with Context'), format_func=lambda x:x,
                       
                       placeholder = "Select answering method...")



#CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template("""Given the following conversation and a follow up question, rephrase the follow up question to be a standalone question.
#Chat History:
#{chat_history}
#Follow Up Input: {question}
#Standalone question:""")



chain = RetrievalQA.from_chain_type(llm=llm,
                                           retriever=db.as_retriever(),
                                           
                                           #condense_question_prompt=CONDENSE_QUESTION_PROMPT,
                                           #return_source_documents=True,
                                           #verbose=False, 
                                           chain_type = choices[options]) 

#uploaded_file = st.sidebar.file_uploader("upload", type="csv")

def conversational_chat(query):
    result = chain.run({"query": query, "chat_history": st.session_state['history']})
    st.session_state['history'].append((query, result))
    return result

if 'history' not in st.session_state:
    st.session_state['history'] = []

if 'generated' not in st.session_state:
    st.session_state['generated'] = ["Hello ! Ask me anything about the map data 🤗"]

if 'past' not in st.session_state:
    st.session_state['past'] = ["Hey ! 👋"]

response_container = st.container()
container = st.container()

with container:
    
    with st.form(key='my_form', clear_on_submit=True):
        user_input = st.text_input("Query:", placeholder="Talk about your data here (:", key='input')
        submit_button = st.form_submit_button(label='Chat')

    if submit_button and user_input:
        output = conversational_chat(user_input)
        st.session_state['past'].append(user_input)
        st.session_state['generated'].append(output)

if st.session_state['generated']:
    with response_container:
        for i in range(len(st.session_state['generated'])):
            message(st.session_state["past"][i], is_user=True, key=str(i) + '_user', avatar_style="adventurer")
            message(st.session_state["generated"][i], key=str(i), avatar_style="bottts", seed = 3)
                


