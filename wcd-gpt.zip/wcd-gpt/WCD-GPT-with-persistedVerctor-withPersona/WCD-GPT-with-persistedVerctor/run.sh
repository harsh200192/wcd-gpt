#!/bin/bash

nohup streamlit run streamlit_wcd_qaretreival.py --server.port 5080 > out.log & echo $! > out.pid
