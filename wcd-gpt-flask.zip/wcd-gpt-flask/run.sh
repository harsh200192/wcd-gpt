#!/bin/bash

python3 wcd-gpt-flask.py > out.log & echo $! > out.pid
