import streamlit as st
from streamlit_chat import message
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain, RetrievalQA
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.vectorstores import FAISS
import tempfile
import os
import openai
from dotenv import load_dotenv
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma, FAISS
from langchain.document_loaders import DirectoryLoader
from langchain.document_loaders import TextLoader
from langchain.text_splitter import TokenTextSplitter
from langchain.document_loaders.csv_loader import CSVLoader
#from langchain.chains import ConversationalRetrievalChain
from langchain import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain.chains import RetrievalQA
from langchain.chains import LLMChain

# Configure Azure OpenAI Service API
openai.api_type = "azure"
openai.api_version = "2023-03-15-preview"

#Init LLM and embeddings model
# Init LLM and embeddings model
llm = AzureChatOpenAI(deployment_name="dep-gpt-4-32k",
                      temperature=0.7,
                      max_tokens=9000,
                      openai_api_version="2023-07-01-preview",
                      openai_api_key='dcf666b8b88d42dfa6595bef3698b4f6',
                      openai_api_base='https://api.chatgpt.tomtom-global.com/')

embedding_1 = OpenAIEmbeddings(model="text-embedding-ada-002",
                    model_kwargs={"engine": 'dep-embed-ada'},
                    openai_api_key='dcf666b8b88d42dfa6595bef3698b4f6',
                    openai_api_base='https://api.chatgpt.tomtom-global.com/',
                    chunk_size=10)


# First, we load up our documents from the `data` directory:

loader = CSVLoader(file_path="2024_jan_new_data.csv") 
data = loader.load()

#Vector Store both FAISS and Chroma work
db = Chroma.from_documents(data, embedding_1)

st.title("WCD-GPT")

#Do a similarity search of the provided query
def retrieve_info(query):
    similar_responce = db.similarity_search(query, k=3)
    page_contents_array = [doc.page_content for doc in similar_responce]
    print(page_contents_array)
    return page_contents_array

#defining a template with system message for the LLM
template = """
You are a world class customer support representative.
With you, you have data that shows what has changes in the latest MNR map version of tomtom.
I wil share with you customer questions related to the map data and you will give me the best answer that I should send to the customer.
You will follow ALL of the results below:

1/ Responce should contain Current MNR Version, County, Map Feature and Map Attribute, with the edit type and edit counts and kms.

2/ If the unit is count, provide reponse from the Edit Count column. If the unit is km then provide the response from the Edit km column.

3/ For feartures such as, IndustrialHarborArea, Country, Neighborhood, Order7Area, AdministrativePlaceM, Built_UpArea, CensusBlock, Order1Area, Order9Area, then insted of km, report it as sqkm.

4/ When a questions is asked about number of countries edites, generated a response by based on the count if distinct country names mentioned in the countries edited column. 

Finally, If the answere to the question is not availble then just say there is no mention of this in the data.

Below is the message I recieved from the customer:
{message}

Here is the map data that you should search from before generating your response.
{map_data}

Please write the best reponse that I should send to this customer:
"""

#defining a promprt
prompt = PromptTemplate(
    input_variables = ["message", "map_data"],
    template = template
)

#creating a veriable and type of responce system
chain = LLMChain(llm=llm, prompt=prompt)

# Rerieval augmented generation
def generate_response(message):
    map_data = retrieve_info(message)
    response = chain.run(message = message, map_data = map_data)
    return response

#choices = {'Short Answer' : 'stuff', 'Answer with Context' : 'refine'}

#options = st.sidebar.selectbox("Answering options:-",
#                       ('Short Answer', 'Answer with Context'), format_func=lambda x:x,                       
#                       placeholder = "Select answering method...")




#chain = RetrievalQA.from_chain_type(llm=llm,
#                                           retriever=db.as_retriever(),
#                                           
#                                           #condense_question_prompt=CONDENSE_QUESTION_PROMPT,
#                                           #return_source_documents=True,
#                                           #verbose=False, 
#                                           chain_type = choices[options]) 

#uploaded_file = st.sidebar.file_uploader("upload", type="csv")

def conversational_chat(query):
    result = chain.run({"query": query, "chat_history": st.session_state['history']})
    st.session_state['history'].append((query, result))
    return result

if 'history' not in st.session_state:
    st.session_state['history'] = []

if 'generated' not in st.session_state:
    st.session_state['generated'] = ["Hello ! Ask me anything about the map data 🤗"]

if 'past' not in st.session_state:
    st.session_state['past'] = ["Hey ! 👋"]

response_container = st.container()
container = st.container()

with container:
    
    with st.form(key='my_form', clear_on_submit=True):
        user_input = st.text_input("Query:", placeholder="Talk about your data here (:", key='input')
        submit_button = st.form_submit_button(label='Chat')

    if submit_button and user_input:
        #output = conversational_chat(user_input)
        output = response = generate_response(user_input)
        st.session_state['past'].append(user_input)
        st.session_state['generated'].append(output)

if st.session_state['generated']:
    with response_container:
        for i in range(len(st.session_state['generated'])):
            message(st.session_state["past"][i], is_user=True, key=str(i) + '_user', avatar_style="adventurer")
            message(st.session_state["generated"][i], key=str(i), avatar_style="bottts", seed = 3)
                