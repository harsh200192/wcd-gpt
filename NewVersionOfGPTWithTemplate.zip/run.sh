#!/bin/bash

nohup streamlit run streamlit_wcd_qaretreival.py > out.log & echo $! > out.pid
